----Project Overview

This project is for a fictional e-commerce store, Julian's. It is aimed at analyzing sales and revenue for its furniture section. Insights from the analysis is intended to drive resource allocation, recognize customer behavior and maximize profitability.


----Datasets

The dataset used in this project was gotten from Kaggle. Changes made to the data was documented in the changelog doc



-----Insights

Post analysis, the ffg was observed;
Tables were the most sold item
Tables pooled the most revenue in the year
Beds were the most profitable product
Products with discounts of 25% or less pooled higher revenue when compared with discounts of above 25%
Winter recorded highest sales. However, revenue was highest in the Fall season
Online Sales recorded higher income compared to retail sales
In terms of material popularity, metal products were the most sold, with its revenue pooling the highest in the year
The best selling color across all products was black. Consequently, its revenue recorded highest
The impact of pricing on products shows that products of $200+ pooled in the most revenue. However, products of other price ranges showed almost the same average profitability 