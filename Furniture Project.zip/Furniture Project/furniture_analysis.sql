
---Calculating the impact of discount % on Revenue and Sales---

SELECT 
  SUM(Revenue) AS total_revenue, SUM(quantity_sold) AS total_sales,
CASE
  WHEN discount_percentage BETWEEN 0.0 AND 25 THEN '25% or Less'
  WHEN discount_percentage >= 25.1 THEN 'Above 25%'
  ELSE 'NIL'
END AS discount_range
FROM
  francis-analytics-course.Furniture_Data.furniture_sales
GROUP BY discount_range;



---Calculating the impact of Pricing on Sales and Revenue---

SELECT 
    CASE 
        WHEN price <= 50 THEN '0-50'
        WHEN price > 50 AND price <= 100 THEN '51-100'
        WHEN price > 100 AND price <= 200 THEN '101-200'
        ELSE '200+'
    END AS price_range,
    SUM(quantity_sold) AS total_sales,
    SUM(revenue) AS total_revenue,
    AVG(profit_margin) AS avg_profit
FROM 
  francis-analytics-course.Furniture_Data.furniture_sales
GROUP BY 
    price_range;